from django.apps import AppConfig


class ApptaskConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'apptask'
